"""
Lambda handler for: Compression + Differential Privacy (NumPy only version)
"""

import os
import json
import numpy as np
import boto3
import io

# AWS Config
s3 = boto3.client("s3")
BUCKET = os.environ.get("S3_BUCKET", "aefl")

# Compression params
MODE = os.environ.get("LAMBDA_COMP_MODE", "topk")
TOPK_FRAC = float(os.environ.get("LAMBDA_TOPK_FRAC", "0.05"))
SPARSITY = float(os.environ.get("LAMBDA_SPARSITY", "0.8"))

# DP params
SIGMA = float(os.environ.get("LAMBDA_DP_SIGMA", "0.1"))


# ============================================================
# Helper: Load PyTorch .pt file (NumPy only)
# ============================================================

def load_pt_state(raw_bytes: bytes):
    """
    Load a PyTorch .pt (state_dict) using numpy's pickle loader.
    This works because state_dict tensors are just numpy arrays underneath.
    """
    buf = io.BytesIO(raw_bytes)
    state = np.load(buf, allow_pickle=True)
    return state.item()   # returns dict


# ============================================================
# Helper: Save as compressed NPZ
# ============================================================

def save_npz_state(state_dict: dict):
    """
    Save state_dict as compressed .npz in memory.
    """
    buf = io.BytesIO()
    np.savez_compressed(buf, **state_dict)
    return buf.getvalue()


# ============================================================
# Top-K Compression (NumPy based)
# ============================================================

def compress_topk(arr: np.ndarray, k_frac: float):
    """
    Keep only top-k largest magnitude weights.
    """
    flat = arr.flatten()
    k = int(len(flat) * k_frac)

    if k < 1:
        return np.zeros_like(arr), 0.0

    # Find threshold
    thresh = np.partition(np.abs(flat), -k)[-k]
    mask = np.abs(arr) >= thresh

    compressed = arr * mask
    kept_ratio = mask.sum() / mask.size
    return compressed, kept_ratio


def apply_compression(state_dict: dict):
    compressed_state = {}
    kept_ratios = []

    for name, arr in state_dict.items():
        if MODE == "topk":
            comp, kept = compress_topk(arr, TOPK_FRAC)
        else:
            # sparsity
            mask = np.random.rand(*arr.shape) > SPARSITY
            comp = arr * mask
            kept = mask.sum() / mask.size

        compressed_state[name] = comp
        kept_ratios.append(kept)

    return compressed_state, float(np.mean(kept_ratios))


# ============================================================
# Differential Privacy (Gaussian Noise)
# ============================================================

def apply_dp_noise(state_dict: dict):
    noisy = {}
    for name, arr in state_dict.items():
        noisy[name] = arr + np.random.normal(scale=SIGMA, size=arr.shape)
    return noisy


# ============================================================
# Lambda Handler
# ============================================================

def handler(event, context):
    role = event["role"]
    round_id = event["round"]
    raw_key = event["raw_key"]
    out_key = event["output_key"]

    # 1) Download raw PyTorch update
    raw = s3.get_object(Bucket=BUCKET, Key=raw_key)["Body"].read()

    # 2) Load PT → NumPy
    state = load_pt_state(raw)

    # 3) Apply DP
    dp_state = apply_dp_noise(state)

    # 4) Apply compression
    comp_state, kept_ratio = apply_compression(dp_state)

    # 5) Save as compressed .npz
    out_bytes = save_npz_state(comp_state)

    # 6) Upload result to S3
    s3.put_object(Bucket=BUCKET, Key=out_key, Body=out_bytes)

    return {
        "round": round_id,
        "role": role,
        "kept_ratio": kept_ratio,
        "status": "OK"
    }
